"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { MapPin, Bed, Bath, Square, Phone, Mail, Calendar } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { useState } from "react"

export default function RealEstatePage() {
  const [filters, setFilters] = useState({
    type: "all",
    location: "all",
    minPrice: "",
    maxPrice: "",
  })

  const properties = [
    {
      id: 1,
      title: "شقة فاخرة في وسط المدينة",
      type: "شقة",
      location: "طرابلس - وسط المدينة",
      price: "250,000",
      bedrooms: 3,
      bathrooms: 2,
      area: 120,
      image: "/placeholder.svg?height=200&width=300",
      features: ["مفروشة", "موقف سيارة", "مصعد", "أمان 24/7"],
      description: "شقة حديثة ومفروشة بالكامل في قلب طرابلس مع إطلالة رائعة على المدينة",
    },
    {
      id: 2,
      title: "فيلا مستقلة مع حديقة",
      type: "فيلا",
      location: "طرابلس - الأندلس",
      price: "450,000",
      bedrooms: 4,
      bathrooms: 3,
      area: 250,
      image: "/placeholder.svg?height=200&width=300",
      features: ["حديقة", "مسبح", "كراج", "غرفة خادمة"],
      description: "فيلا فاخرة مع حديقة واسعة ومسبح خاص في منطقة راقية",
    },
    {
      id: 3,
      title: "محل تجاري على الشارع الرئيسي",
      type: "محل تجاري",
      location: "طرابلس - شارع الجمهورية",
      price: "180,000",
      bedrooms: 0,
      bathrooms: 1,
      area: 80,
      image: "/placeholder.svg?height=200&width=300",
      features: ["واجهة زجاجية", "موقع مميز", "مكيف", "إنترنت"],
      description: "محل تجاري في موقع استراتيجي على أحد أهم الشوارع التجارية",
    },
    {
      id: 4,
      title: "أرض للبناء في منطقة هادئة",
      type: "أرض",
      location: "طرابلس - قرقارش",
      price: "120,000",
      bedrooms: 0,
      bathrooms: 0,
      area: 400,
      image: "/placeholder.svg?height=200&width=300",
      features: ["زاوية", "مخططة", "خدمات متوفرة", "منطقة هادئة"],
      description: "قطعة أرض مميزة للبناء في منطقة سكنية هادئة ومخططة",
    },
    {
      id: 5,
      title: "مكتب إداري مجهز",
      type: "مكتب",
      location: "طرابلس - برج الفاتح",
      price: "95,000",
      bedrooms: 0,
      bathrooms: 1,
      area: 60,
      image: "/placeholder.svg?height=200&width=300",
      features: ["مجهز بالكامل", "إنترنت عالي السرعة", "أمان", "موقف سيارات"],
      description: "مكتب حديث ومجهز بالكامل في برج تجاري مميز",
    },
    {
      id: 6,
      title: "شقة عائلية واسعة",
      type: "شقة",
      location: "طرابلس - الدريبي",
      price: "320,000",
      bedrooms: 4,
      bathrooms: 3,
      area: 180,
      image: "/placeholder.svg?height=200&width=300",
      features: ["شرفة واسعة", "مطبخ حديث", "تدفئة مركزية", "قريبة من المدارس"],
      description: "شقة عائلية واسعة ومريحة في منطقة سكنية مميزة",
    },
  ]

  const [selectedProperty, setSelectedProperty] = useState<number | null>(null)

  const handleBookVisit = (propertyId: number) => {
    setSelectedProperty(propertyId)
    // Here you would typically open a modal or navigate to a booking form
    alert("سيتم التواصل معك لتحديد موعد الزيارة")
  }

  const filteredProperties = properties.filter((property) => {
    if (filters.type !== "all" && property.type !== filters.type) return false
    if (filters.location !== "all" && !property.location.includes(filters.location)) return false
    if (filters.minPrice && Number.parseInt(property.price.replace(",", "")) < Number.parseInt(filters.minPrice))
      return false
    if (filters.maxPrice && Number.parseInt(property.price.replace(",", "")) > Number.parseInt(filters.maxPrice))
      return false
    return true
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-4 space-x-reverse">
              <Image
                src="/logos/wast-realestate-logo.jpeg"
                alt="وسط للعقارات"
                width={40}
                height={40}
                className="rounded-lg"
              />
              <div>
                <h1 className="text-xl font-bold text-gray-900">وسط للعقارات</h1>
              </div>
            </Link>
            <nav className="hidden md:flex items-center space-x-6 space-x-reverse">
              <Link href="/" className="text-gray-700 hover:text-green-600 font-medium">
                الرئيسية
              </Link>
              <Link href="#properties" className="text-gray-700 hover:text-green-600 font-medium">
                العقارات
              </Link>
              <Link href="#contact" className="text-gray-700 hover:text-green-600 font-medium">
                تواصل معنا
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-blue-800 to-cyan-500 text-white">
        <div className="container mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">وسط للعقارات</h1>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            نساعدك في العثور على العقار المثالي سواء للسكن أو الاستثمار مع أفضل الأسعار والمواقع المميزة
          </p>
        </div>
      </section>

      {/* Search Filters */}
      <section className="py-8 px-4 bg-white shadow-sm">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="type">نوع العقار</Label>
              <Select onValueChange={(value) => setFilters({ ...filters, type: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="جميع الأنواع" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الأنواع</SelectItem>
                  <SelectItem value="شقة">شقة</SelectItem>
                  <SelectItem value="فيلا">فيلا</SelectItem>
                  <SelectItem value="محل تجاري">محل تجاري</SelectItem>
                  <SelectItem value="مكتب">مكتب</SelectItem>
                  <SelectItem value="أرض">أرض</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="location">المنطقة</Label>
              <Select onValueChange={(value) => setFilters({ ...filters, location: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="جميع المناطق" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع المناطق</SelectItem>
                  <SelectItem value="وسط المدينة">وسط المدينة</SelectItem>
                  <SelectItem value="الأندلس">الأندلس</SelectItem>
                  <SelectItem value="قرقارش">قرقارش</SelectItem>
                  <SelectItem value="الدريبي">الدريبي</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="minPrice">السعر الأدنى</Label>
              <Input
                id="minPrice"
                type="number"
                placeholder="0"
                value={filters.minPrice}
                onChange={(e) => setFilters({ ...filters, minPrice: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="maxPrice">السعر الأعلى</Label>
              <Input
                id="maxPrice"
                type="number"
                placeholder="1000000"
                value={filters.maxPrice}
                onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value })}
              />
            </div>
          </div>
        </div>
      </section>

      {/* Properties Grid */}
      <section id="properties" className="py-16 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">العقارات المتاحة</h2>
            <p className="text-lg text-gray-600">اختر من مجموعة متنوعة من العقارات المميزة</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProperties.map((property) => (
              <Card key={property.id} className="hover:shadow-xl transition-shadow duration-300 overflow-hidden">
                <div className="relative">
                  <Image
                    src={property.image || "/placeholder.svg"}
                    alt={property.title}
                    width={300}
                    height={200}
                    className="w-full h-48 object-cover"
                  />
                  <Badge className="absolute top-4 right-4 bg-green-600">{property.type}</Badge>
                </div>
                <CardHeader>
                  <CardTitle className="text-lg font-bold">{property.title}</CardTitle>
                  <CardDescription className="flex items-center text-gray-600">
                    <MapPin className="h-4 w-4 ml-1" />
                    {property.location}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-4">
                    <div className="text-2xl font-bold text-green-600">{property.price} د.ل</div>
                  </div>

                  {property.bedrooms > 0 && (
                    <div className="flex items-center space-x-4 space-x-reverse text-sm text-gray-600 mb-4">
                      <div className="flex items-center">
                        <Bed className="h-4 w-4 ml-1" />
                        {property.bedrooms} غرف
                      </div>
                      <div className="flex items-center">
                        <Bath className="h-4 w-4 ml-1" />
                        {property.bathrooms} حمام
                      </div>
                      <div className="flex items-center">
                        <Square className="h-4 w-4 ml-1" />
                        {property.area} م²
                      </div>
                    </div>
                  )}

                  <p className="text-sm text-gray-600 mb-4">{property.description}</p>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {property.features.slice(0, 3).map((feature, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex gap-2">
                    <Button
                      className="flex-1 bg-blue-800 hover:bg-blue-900"
                      onClick={() => handleBookVisit(property.id)}
                    >
                      <Calendar className="h-4 w-4 ml-1" />
                      احجز زيارة
                    </Button>
                    <Button variant="outline" className="flex-1 bg-transparent">
                      استفسر
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredProperties.length === 0 && (
            <div className="text-center py-12">
              <p className="text-lg text-gray-600">لا توجد عقارات تطابق معايير البحث</p>
            </div>
          )}
        </div>
      </section>

      {/* Virtual Tours & Showcase */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">جولات افتراضية وعروض توضيحية</h2>
            <p className="text-lg text-gray-600">استكشف العقارات من منزلك بتقنية الجولة الافتراضية</p>
          </div>

          {/* Featured Virtual Tour */}
          <div className="mb-12">
            <Card className="overflow-hidden">
              <CardContent className="p-0">
                <div className="relative">
                  <Image
                    src="/placeholder.svg?height=400&width=800"
                    alt="جولة افتراضية"
                    width={800}
                    height={400}
                    className="w-full h-96 object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                    <Button 
                      size="lg" 
                      className="bg-green-600 hover:bg-green-700 text-white"
                      onClick={() => window.open("https://www.youtube.com/watch?v=dQw4w9WgXcQ", "_blank")}
                    >
                      <svg className="w-8 h-8 ml-2" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M8 5v14l11-7z"/>
                      </svg>
                      ابدأ الجولة الافتراضية
                    </Button>
                  </div>
                  <div className="absolute bottom-4 left-4 text-white">
                    <h3 className="text-xl font-bold">فيلا فاخرة في الأندلس</h3>
                    <p>جولة افتراضية 360 درجة</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Property Showcase Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {[
              {
                title: "شقة مفروشة - وسط المدينة",
                type: "جولة افتراضية",
                image: "/placeholder.svg?height=200&width=300",
                duration: "5 دقائق"
              },
              {
                title: "محل تجاري - شارع الجمهورية",
                type: "فيديو توضيحي",
                image: "/placeholder.svg?height=200&width=300",
                duration: "3 دقائق"
              },
              {
                title: "أرض للبناء - قرقارش",
                type: "عرض بالطائرة المسيرة",
                image: "/placeholder.svg?height=200&width=300",
                duration: "4 دقائق"
              },
              {
                title: "مكتب إداري - برج الفاتح",
                type: "جولة افتراضية",
                image: "/placeholder.svg?height=200&width=300",
                duration: "6 دقائق"
              },
              {
                title: "شقة عائلية - الدريبي",
                type: "فيديو توضيحي",
                image: "/placeholder.svg?height=200&width=300",
                duration: "7 دقائق"
              },
              {
                title: "فيلا مع حديقة - الأندلس",
                type: "جولة شاملة",
                image: "/placeholder.svg?height=200&width=300",
                duration: "10 دقائق"
              }
            ].map((showcase, index) => (
              <Card key={index} className="group hover:shadow-lg transition-shadow overflow-hidden cursor-pointer">
                <div className="relative">
                  <Image
                    src={showcase.image || "/placeholder.svg"}
                    alt={showcase.title}
                    width={300}
                    height={200}
                    className="w-full h-40 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Button size="sm" className="bg-white text-gray-900 hover:bg-gray-100">
                      <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M8 5v14l11-7z"/>
                      </svg>
                      مشاهدة
                    </Button>
                  </div>
                  <div className="absolute top-2 right-2">
                    <Badge className="bg-green-600 text-white">{showcase.type}</Badge>
                  </div>
                  <div className="absolute bottom-2 left-2">
                    <Badge variant="secondary" className="bg-black bg-opacity-50 text-white">
                      {showcase.duration}
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold text-gray-900">{showcase.title}</h3>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Success Stories */}
          <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-8">
            <h3 className="text-2xl font-bold text-center text-gray-900 mb-8">قصص نجاح</h3>
            <div className="grid md:grid-cols-3 gap-6">
              {[
                {
                  title: "بيع فيلا في أسبوع واحد",
                  description: "تم بيع فيلا فاخرة خلال أسبوع واحد بفضل الجولة الافتراضية والتسويق الفعال",
                  result: "100% من السعر المطلوب"
                },
                {
                  title: "تأجير 15 شقة في شهر",
                  description: "نجحنا في تأجير 15 شقة لعميل واحد خلال شهر واحد",
                  result: "معدل إشغال 95%"
                },
                {
                  title: "بيع أرض استثمارية",
                  description: "بيع قطعة أرض كبيرة لمستثمر أجنبي بعد عرض شامل بالطائرة المسيرة",
                  result: "زيادة 20% عن السعر المتوقع"
                }
              ].map((story, index) => (
                <Card key={index} className="bg-white">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <svg className="w-8 h-8 text-green-600" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                      </svg>
                    </div>
                    <h4 className="font-bold text-gray-900 mb-3">{story.title}</h4>
                    <p className="text-gray-600 text-sm mb-4">{story.description}</p>
                    <Badge className="bg-green-600">{story.result}</Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-16 px-4 bg-white">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">تواصل معنا</h2>
            <p className="text-lg text-gray-600">نحن هنا لمساعدتك في العثور على العقار المثالي</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-cyan-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Phone className="h-6 w-6 text-cyan-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">الهاتف</h3>
                <p className="text-gray-600">+218 91 234 5678</p>
                <Button className="mt-4 w-full bg-green-600 hover:bg-green-700">اتصل الآن</Button>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Mail className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">البريد الإلكتروني</h3>
                <p className="text-gray-600">realestate@wasat.ly</p>
                <Button variant="outline" className="mt-4 w-full bg-transparent">
                  أرسل رسالة
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MapPin className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">المكتب</h3>
                <p className="text-gray-600">طرابلس، ليبيا</p>
                <Button variant="outline" className="mt-4 w-full bg-transparent">
                  عرض الموقع
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 px-4">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 space-x-reverse mb-4">
            <Image
              src="/logos/wast-realestate-logo.jpeg"
              alt="وسط للعقارات"
              width={32}
              height={32}
              className="rounded-lg"
            />
            <span className="text-xl font-bold">وسط للعقارات</span>
          </div>
          <p className="text-gray-400 mb-4">جزء من مجموعة وسط للخدمات التسويقية</p>
          <div className="flex justify-center space-x-2 space-x-reverse flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              className="text-white border-white hover:bg-white hover:text-gray-900 bg-transparent"
              onClick={() => window.open("https://wa.me/218912345679", "_blank")}
            >
              <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488" />
              </svg>
              واتساب
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="text-white border-white hover:bg-white hover:text-gray-900 bg-transparent"
              onClick={() => window.open("https://facebook.com/wasat.realestate", "_blank")}
            >
              <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
              </svg>
              فيسبوك
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="text-white border-white hover:bg-white hover:text-gray-900 bg-transparent"
              onClick={() => window.open("https://instagram.com/wasat.realestate", "_blank")}
            >
              <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.2\
