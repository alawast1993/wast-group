"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Target, Eye, Users, Award, Building, Lightbulb } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function AboutPage() {
  const branches = [
    {
      id: "marketing",
      title: "وسط آيديا",
      description: "الذراع الإبداعي للمجموعة، ويُعنى بالتسويق الرقمي وتصميم الهويات البصرية",
      icon: <Lightbulb className="h-8 w-8" />,
      color: "bg-blue-500",
    },
    {
      id: "real-estate",
      title: "وسط للعقارات",
      description: "شركة وسيطة متخصصة في التسويق العقاري، البيع، الإيجار، والاستشارات العقارية",
      icon: <Building className="h-8 w-8" />,
      color: "bg-green-500",
    },
    {
      id: "electronics",
      title: "متجر وسطكم",
      description: "متجر إلكتروني متخصص في بيع الأجهزة الإلكترونية ومستلزماتها",
      icon: <Award className="h-8 w-8" />,
      color: "bg-purple-500",
    },
    {
      id: "home",
      title: "متجر وسط هوم",
      description: "متجر للمستلزمات المنزلية والديكور، يوفر منتجات مميزة بجودة عالية",
      icon: <Users className="h-8 w-8" />,
      color: "bg-orange-500",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-4 space-x-reverse">
              <Image src="/logos/wasat-group-main.png" alt="مجموعة وسط" width={40} height={40} className="rounded-lg" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">مجموعة وسط</h1>
                <p className="text-sm text-gray-600">للخدمات التسويقية</p>
              </div>
            </Link>
            <nav className="hidden md:flex items-center space-x-6 space-x-reverse">
              <Link href="/" className="text-gray-700 hover:text-blue-600 font-medium">
                الرئيسية
              </Link>
              <Link href="/about" className="text-blue-600 font-medium">
                من نحن
              </Link>
              <Link href="/contact" className="text-gray-700 hover:text-blue-600 font-medium">
                تواصل معنا
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-blue-800 to-cyan-500 text-white">
        <div className="container mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">من نحن</h1>
          <p className="text-xl mb-8 max-w-3xl mx-auto">مجموعة وسط للخدمات التسويقية - شريكك في النجاح والتميز</p>
        </div>
      </section>

      {/* About Content */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          {/* Introduction */}
          <Card className="mb-12">
            <CardContent className="p-8">
              <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">مجموعة وسط للخدمات التسويقية</h2>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                مجموعة وسط للخدمات التسويقية هي مجموعة متكاملة تأسست لتقديم حلول إبداعية وعملية في مجالات التسويق،
                التصميم، العقارات، والتجارة الإلكترونية. نهدف إلى ربط الأفكار المبتكرة باحتياجات السوق المحلي، وتقديم
                خدمات احترافية ترتقي بأعمال عملائنا وتساعدهم على التميز.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed">
                نحن نؤمن بأن التخصص والاحترافية هما سر النجاح، لذلك أنشأنا عدة كيانات متخصصة تحت مظلة المجموعة لتقديم
                تجربة متكاملة تغطي جميع احتياجات عملائنا في التسويق والتصميم والعقارات والتجارة الإلكترونية، بأسلوب يجمع
                بين الحداثة والموثوقية.
              </p>
            </CardContent>
          </Card>

          {/* Mission and Vision */}
          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200">
              <CardHeader>
                <div className="flex items-center space-x-3 space-x-reverse">
                  <Target className="h-8 w-8 text-blue-600" />
                  <CardTitle className="text-2xl text-blue-800">✨ رسالتنا</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  تمكين المؤسسات والأفراد من النجاح في السوق من خلال حلول مرنة، مدروسة، ومبنية على فهم حقيقي للاحتياج
                  والهوية.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-50 to-cyan-50 border-green-200">
              <CardHeader>
                <div className="flex items-center space-x-3 space-x-reverse">
                  <Eye className="h-8 w-8 text-green-600" />
                  <CardTitle className="text-2xl text-green-800">🎯 رؤيتنا</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  أن نكون من أوائل المجموعات المتخصصة في ليبيا والمنطقة في تقديم خدمات تسويقية وتجارية متكاملة بروح
                  محلية ومعايير عالمية.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Branches Section */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">فروع المجموعة</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {branches.map((branch) => (
                <Card key={branch.id} className="hover:shadow-lg transition-shadow duration-300">
                  <CardHeader>
                    <div className="flex items-center space-x-4 space-x-reverse">
                      <div
                        className={`w-16 h-16 ${branch.color} rounded-xl flex items-center justify-center text-white`}
                      >
                        {branch.icon}
                      </div>
                      <div>
                        <CardTitle className="text-xl font-bold text-gray-900">{branch.title}</CardTitle>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 leading-relaxed">{branch.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Values Section */}
          <Card className="mb-12">
            <CardHeader>
              <CardTitle className="text-2xl text-center">قيمنا ومبادئنا</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Award className="h-8 w-8 text-blue-600" />
                  </div>
                  <h3 className="font-bold text-gray-900 mb-2">الجودة</h3>
                  <p className="text-gray-600 text-sm">نلتزم بأعلى معايير الجودة في جميع خدماتنا</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Users className="h-8 w-8 text-green-600" />
                  </div>
                  <h3 className="font-bold text-gray-900 mb-2">العمل الجماعي</h3>
                  <p className="text-gray-600 text-sm">نؤمن بقوة الفريق والتعاون لتحقيق أفضل النتائج</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Lightbulb className="h-8 w-8 text-purple-600" />
                  </div>
                  <h3 className="font-bold text-gray-900 mb-2">الإبداع</h3>
                  <p className="text-gray-600 text-sm">نسعى للابتكار والإبداع في كل ما نقدمه</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact CTA */}
          <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200">
            <CardContent className="p-8 text-center">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">هل تريد معرفة المزيد؟</h3>
              <p className="text-gray-600 mb-6 text-lg">
                تواصل معنا لمعرفة كيف يمكن لمجموعة وسط مساعدتك في تحقيق أهدافك
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link href="/contact">
                  <Button className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-3">
                    تواصل معنا
                    <ArrowLeft className="mr-2 h-5 w-5" />
                  </Button>
                </Link>
                <Link href="/">
                  <Button variant="outline" className="text-lg px-8 py-3">
                    استكشف خدماتنا
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 space-x-reverse mb-4">
                <Image
                  src="/logos/wasat-group-main.png"
                  alt="مجموعة وسط"
                  width={32}
                  height={32}
                  className="rounded-lg"
                />
                <span className="text-xl font-bold">مجموعة وسط</span>
              </div>
              <p className="text-gray-400 text-sm">مجموعة متكاملة من الخدمات التسويقية والتجارية المتطورة</p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">فروعنا</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link href="/marketing" className="hover:text-white">
                    وسط آيديا
                  </Link>
                </li>
                <li>
                  <Link href="/real-estate" className="hover:text-white">
                    العقارات
                  </Link>
                </li>
                <li>
                  <Link href="/electronics" className="hover:text-white">
                    الإلكترونيات
                  </Link>
                </li>
                <li>
                  <Link href="/home-store" className="hover:text-white">
                    المستلزمات المنزلية
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">روابط سريعة</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link href="/about" className="hover:text-white text-blue-400">
                    من نحن
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white">
                    تواصل معنا
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-white">
                    سياسة الخصوصية
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-white">
                    الشروط والأحكام
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">تابعنا</h3>
              <div className="flex space-x-4 space-x-reverse">
                <a
                  href="https://www.facebook.com/wast.group"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center hover:bg-blue-700"
                >
                  <span className="text-xs">ف</span>
                </a>
                <a
                  href="https://wa.me/218919835505"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center hover:bg-green-700"
                >
                  <span className="text-xs">و</span>
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2024 مجموعة وسط للخدمات التسويقية. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
