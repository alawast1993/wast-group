"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Home, Sofa, Utensils, Lightbulb, ShoppingCart, Star, Search } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { useState } from "react"

export default function HomeStorePage() {
  const [cart, setCart] = useState<{ [key: number]: number }>({})
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")

  const products = [
    {
      id: 1,
      name: "طقم أريكة مودرن 3+2+1",
      category: "أثاث",
      price: 1200,
      originalPrice: 1400,
      rating: 4.7,
      reviews: 45,
      image: "/placeholder.svg?height=200&width=200",
      description: "طقم أريكة عصري مريح مصنوع من أجود الخامات مع وسائد قابلة للإزالة",
      features: ["قماش مقاوم للبقع", "إطار خشبي قوي", "وسائد قابلة للغسل", "ضمان سنتين"],
      inStock: true,
      isNew: true,
    },
    {
      id: 2,
      name: "طاولة طعام خشبية 6 أشخاص",
      category: "أثاث",
      price: 800,
      originalPrice: 950,
      rating: 4.8,
      reviews: 32,
      image: "/placeholder.svg?height=200&width=200",
      description: "طاولة طعام أنيقة من الخشب الطبيعي تتسع لـ 6 أشخاص",
      features: ["خشب طبيعي", "تصميم كلاسيكي", "سهلة التنظيف", "مقاومة للخدش"],
      inStock: true,
      isNew: false,
    },
    {
      id: 3,
      name: "مجموعة أواني طبخ غير لاصقة",
      category: "أدوات مطبخ",
      price: 250,
      originalPrice: 300,
      rating: 4.6,
      reviews: 78,
      image: "/placeholder.svg?height=200&width=200",
      description: "مجموعة كاملة من أواني الطبخ غير اللاصقة مع أغطية زجاجية",
      features: ["طلاء غير لاصق", "مقابض مقاومة للحرارة", "آمنة للغسالة", "12 قطعة"],
      inStock: true,
      isNew: true,
    },
    {
      id: 4,
      name: "ثريا كريستال فاخرة",
      category: "إضاءة",
      price: 450,
      originalPrice: 550,
      rating: 4.9,
      reviews: 23,
      image: "/placeholder.svg?height=200&width=200",
      description: "ثريا كريستال أنيقة تضفي لمسة من الفخامة على منزلك",
      features: ["كريستال أصلي", "إضاءة LED", "جهاز تحكم عن بعد", "سهلة التركيب"],
      inStock: false,
      isNew: false,
    },
    {
      id: 5,
      name: "سجادة فارسية كلاسيكية",
      category: "ديكور",
      price: 350,
      originalPrice: 400,
      rating: 4.5,
      reviews: 56,
      image: "/placeholder.svg?height=200&width=200",
      description: "سجادة فارسية بتصميم كلاسيكي جميل وألوان زاهية",
      features: ["نسيج عالي الجودة", "ألوان ثابتة", "مقاس 200×300 سم", "سهلة التنظيف"],
      inStock: true,
      isNew: false,
    },
    {
      id: 6,
      name: "مرآة حائط ديكورية",
      category: "ديكور",
      price: 120,
      originalPrice: 150,
      rating: 4.4,
      reviews: 34,
      image: "/placeholder.svg?height=200&width=200",
      description: "مرآة حائط بإطار ذهبي أنيق تناسب جميع أنواع الديكور",
      features: ["إطار معدني", "مرآة عالية الوضوح", "سهلة التعليق", "مقاومة للرطوبة"],
      inStock: true,
      isNew: true,
    },
  ]

  const categories = [
    { id: "furniture", name: "أثاث", icon: <Sofa className="h-5 w-5" /> },
    { id: "kitchen", name: "أدوات مطبخ", icon: <Utensils className="h-5 w-5" /> },
    { id: "lighting", name: "إضاءة", icon: <Lightbulb className="h-5 w-5" /> },
    { id: "decor", name: "ديكور", icon: <Home className="h-5 w-5" /> },
  ]

  const addToCart = (productId: number) => {
    setCart((prev) => ({
      ...prev,
      [productId]: (prev[productId] || 0) + 1,
    }))
  }

  const getCartTotal = () => {
    return Object.entries(cart).reduce((total, [productId, quantity]) => {
      const product = products.find((p) => p.id === Number.parseInt(productId))
      return total + (product ? product.price * quantity : 0)
    }, 0)
  }

  const getCartItemsCount = () => {
    return Object.values(cart).reduce((total, quantity) => total + quantity, 0)
  }

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = categoryFilter === "all" || product.category === categoryFilter

    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-4 space-x-reverse">
              <Image
                src="/logos/wast-home-logo.jpeg"
                alt="متجر وسط هوم"
                width={40}
                height={40}
                className="rounded-lg"
              />
              <div>
                <h1 className="text-xl font-bold text-gray-900">متجر وسط هوم</h1>
                <p className="text-sm text-gray-600">للمستلزمات المنزلية</p>
              </div>
            </Link>
            <div className="flex items-center space-x-4 space-x-reverse">
              <Button variant="outline" className="relative bg-transparent">
                <ShoppingCart className="h-5 w-5 ml-2" />
                السلة
                {getCartItemsCount() > 0 && (
                  <Badge className="absolute -top-2 -right-2 bg-red-500 text-white text-xs">
                    {getCartItemsCount()}
                  </Badge>
                )}
              </Button>
              <nav className="hidden md:flex items-center space-x-6 space-x-reverse">
                <Link href="/" className="text-gray-700 hover:text-orange-600 font-medium">
                  الرئيسية
                </Link>
                <Link href="#products" className="text-gray-700 hover:text-orange-600 font-medium">
                  المنتجات
                </Link>
                <Link href="#contact" className="text-gray-700 hover:text-orange-600 font-medium">
                  تواصل معنا
                </Link>
              </nav>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-blue-800 to-cyan-500 text-white">
        <div className="container mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">متجر وسط هوم للمستلزمات المنزلية</h1>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            كل ما تحتاجه لجعل منزلك أكثر جمالاً وراحة من أثاث عصري وديكورات أنيقة وأدوات منزلية عملية
          </p>
        </div>
      </section>

      {/* Categories */}
      <section className="py-8 px-4 bg-white">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-4">
            {categories.map((category) => (
              <Card key={category.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-4 text-center">
                  <div className="w-12 h-12 bg-cyan-100 rounded-full flex items-center justify-center mx-auto mb-3 text-cyan-600">
                    {category.icon}
                  </div>
                  <h3 className="font-semibold text-gray-900">{category.name}</h3>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Search and Filters */}
      <section className="py-8 px-4 bg-gray-50">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-2 gap-4 max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="ابحث عن المنتجات..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10"
              />
            </div>
            <div>
              <Select onValueChange={setCategoryFilter} value={categoryFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="جميع الفئات" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الفئات</SelectItem>
                  <SelectItem value="أثاث">أثاث</SelectItem>
                  <SelectItem value="أدوات مطبخ">أدوات مطبخ</SelectItem>
                  <SelectItem value="إضاءة">إضاءة</SelectItem>
                  <SelectItem value="ديكور">ديكور</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </section>

      {/* Product Showcase & Room Inspiration */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">معرض المنتجات وأفكار التصميم</h2>
            <p className="text-lg text-gray-600">اكتشف كيف تبدو منتجاتنا في المنازل الحقيقية</p>
          </div>

          {/* Featured Room Tour */}
          <div className="mb-12">
            <Card className="overflow-hidden">
              <CardContent className="p-0">
                <div className="relative">
                  <Image
                    src="/placeholder.svg?height=400&width=800"
                    alt="جولة في المنزل"
                    width={800}
                    height={400}
                    className="w-full h-96 object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                    <Button 
                      size="lg" 
                      className="bg-orange-600 hover:bg-orange-700 text-white"
                      onClick={() => window.open("https://www.youtube.com/watch?v=dQw4w9WgXcQ", "_blank")}
                    >
                      <svg className="w-8 h-8 ml-2" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M8 5v14l11-7z"/>
                      </svg>
                      جولة في منزل مفروش بالكامل
                    </Button>
                  </div>
                  <div className="absolute bottom-4 left-4 text-white">
                    <h3 className="text-xl font-bold">منزل عصري مفروش بمنتجات وسط هوم</h3>
                    <p>شاهد التناسق والأناقة في كل غرفة</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Room Inspiration Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {[
              {
                title: "غرفة معيشة عصرية",
                products: "أريكة + طاولة قهوة + سجادة",
                image: "/placeholder.svg?height=250&width=350",
                price: "3,200 د.ل",
                originalPrice: "3,800 د.ل"
              },
              {
                title: "غرفة نوم رومانسية",
                products: "سرير + كومودينو + مرآة",
                image: "/placeholder.svg?height=250&width=350",
                price: "2,800 د.ل",
                originalPrice: "3,200 د.ل"
              },
              {
                title: "مطبخ أنيق ومنظم",
                products: "أواني طبخ + أدوات تنظيم",
                image: "/placeholder.svg?height=250&width=350",
                price: "850 د.ل",
                originalPrice: "1,000 د.ل"
              },
              {
                title: "مكتب منزلي مريح",
                products: "مكتب + كرسي + إضاءة",
                image: "/placeholder.svg?height=250&width=350",
                price: "1,500 د.ل",
                originalPrice: "1,750 د.ل"
              },
              {
                title: "حمام فاخر",
                products: "إكسسوارات حمام + مرآة",
                image: "/placeholder.svg?height=250&width=350",
                price: "650 د.ل",
                originalPrice: "800 د.ل"
              },
              {
                title: "شرفة مريحة",
                products: "أثاث خارجي + نباتات",
                image: "/placeholder.svg?height=250&width=350",
                price: "1,200 د.ل",
                originalPrice: "1,400 د.ل"
              }
            ].map((room, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 overflow-hidden">
                <div className="relative overflow-hidden">
                  <Image
                    src={room.image || "/placeholder.svg"}
                    alt={room.title}
                    width={350}
                    height={250}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-orange-600">باقة كاملة</Badge>
                  </div>
                  <div className="absolute inset-0 bg-black bg-opacity-30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Button size="sm" className="bg-white text-gray-900 hover:bg-gray-100">
                      <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                        <path d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                      </svg>
                      استكشف
                    </Button>
                  </div>
                </div>
                <CardContent className="p-4">
                  <h3 className="font-bold text-gray-900 mb-2">{room.title}</h3>
                  <p className="text-gray-600 text-sm mb-3">{room.products}</p>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-lg font-bold text-orange-600">{room.price}</div>
                      <div className="text-sm text-gray-500 line-through">{room.originalPrice}</div>
                    </div>
                    <Button size="sm" className="bg-orange-600 hover:bg-orange-700">
                      اطلب الباقة
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Before & After Transformations */}
          <div className="bg-gradient-to-r from-orange-50 to-yellow-50 rounded-lg p-8">
            <h3 className="text-2xl font-bold text-center text-gray-900 mb-8">تحولات مذهلة - قبل وبعد</h3>
            <div className="grid md:grid-cols-2 gap-8">
              {[
                {
                  title: "تجديد غرفة المعيشة",
                  beforeImage: "/placeholder.svg?height=200&width=300",
                  afterImage: "/placeholder.svg?height=200&width=300",
                  description: "تحويل غرفة معيشة تقليدية إلى مساحة عصرية وأنيقة"
                },
                {
                  title: "تطوير غرفة النوم",
                  beforeImage: "/placeholder.svg?height=200&width=300",
                  afterImage: "/placeholder.svg?height=200&width=300",
                  description: "إعادة تصميم غرفة نوم لتصبح واحة من الراحة والهدوء"
                }
              ].map((transformation, index) => (
                <Card key={index} className="bg-white">
                  <CardContent className="p-6">
                    <h4 className="font-bold text-gray-900 mb-4 text-center">{transformation.title}</h4>
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <p className="text-sm text-gray-600 mb-2 text-center">قبل</p>
                        <Image
                          src={transformation.beforeImage || "/placeholder.svg"}
                          alt="قبل"
                          width={300}
                          height={200}
                          className="w-full h-32 object-cover rounded-lg"
                        />
                      </div>
                      <div>
                        <p className="text-sm text-gray-600 mb-2 text-center">بعد</p>
                        <Image
                          src={transformation.afterImage || "/placeholder.svg"}
                          alt="بعد"
                          width={300}
                          height={200}
                          className="w-full h-32 object-cover rounded-lg"
                        />
                      </div>
                    </div>
                    <p className="text-gray-600 text-sm text-center">{transformation.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* DIY Tips & Tutorials */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">نصائح وإرشادات التصميم</h2>
            <p className="text-lg text-gray-600">تعلم كيفية تنسيق منزلك بنفسك مع خبرائنا</p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                title: "كيفية اختيار الألوان المناسبة",
                image: "/placeholder.svg?height=200&width=300",
                duration: "5 دقائق",
                category: "نصائح تصميم"
              },
              {
                title: "ترتيب الأثاث في المساحات الصغيرة",
                image: "/placeholder.svg?height=200&width=300",
                duration: "8 دقائق",
                category: "تنظيم المساحات"
              },
              {
                title: "إضافة النباتات لتحسين الديكور",
                image: "/placeholder.svg?height=200&width=300",
                duration: "6 دقائق",
                category: "ديكور طبيعي"
              },
              {
                title: "الإضاءة المثالية لكل غرفة",
                image: "/placeholder.svg?height=200&width=300",
                duration: "7 دقائق",
                category: "إضاءة"
              },
              {
                title: "تنسيق الوسائد والستائر",
                image: "/placeholder.svg?height=200&width=300",
                duration: "4 دقائق",
                category: "إكسسوارات"
              },
              {
                title: "تنظيم المطبخ بطريقة عملية",
                image: "/placeholder.svg?height=200&width=300",
                duration: "9 دقائق",
                category: "تنظيم"
              }
            ].map((tip, index) => (
              <Card key={index} className="group hover:shadow-lg transition-shadow overflow-hidden cursor-pointer">
                <div className="relative">
                  <Image
                    src={tip.image || "/placeholder.svg"}
                    alt={tip.title}
                    width={300}
                    height={200}
                    className="w-full h-40 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Button size="sm" className="bg-white text-gray-900 hover:bg-gray-100">
                      <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M8 5v14l11-7z"/>
                      </svg>
                      مشاهدة
                    </Button>
                  </div>
                  <div className="absolute top-2 right-2">
                    <Badge className="bg-orange-600 text-white">{tip.category}</Badge>
                  </div>
                  <div className="absolute bottom-2 left-2">
                    <Badge variant="secondary" className="bg-black bg-opacity-50 text-white">
                      {tip.duration}
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold text-gray-900">{tip.title}</h3>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section id="products" className="py-16 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">منتجاتنا</h2>
            <p className="text-lg text-gray-600">اختر من مجموعة متنوعة من المستلزمات المنزلية عالية الجودة</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map((product) => (
              <Card key={product.id} className="hover:shadow-xl transition-shadow duration-300 overflow-hidden">
                <div className="relative">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    width={200}
                    height={200}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-4 right-4 flex flex-col gap-2">
                    {product.isNew && <Badge className="bg-green-600">جديد</Badge>}
                    {product.originalPrice > product.price && <Badge className="bg-red-600">خصم</Badge>}
                    {!product.inStock && <Badge variant="secondary">نفد المخزون</Badge>}
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-lg font-bold">{product.name}</CardTitle>
                  <CardDescription className="text-gray-600">{product.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center mb-3">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${
                            i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-600 mr-2">({product.reviews} تقييم)</span>
                  </div>

                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <div className="text-2xl font-bold text-orange-600">{product.price} د.ل</div>
                      {product.originalPrice > product.price && (
                        <div className="text-sm text-gray-500 line-through">{product.originalPrice} د.ل</div>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1 mb-4">
                    {product.features.slice(0, 2).map((feature, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex gap-2">
                    <Button
                      className="flex-1 bg-blue-800 hover:bg-blue-900"
                      onClick={() => addToCart(product.id)}
                      disabled={!product.inStock}
                    >
                      <ShoppingCart className="h-4 w-4 ml-1" />
                      {product.inStock ? "أضف للسلة" : "نفد المخزون"}
                    </Button>
                    <Button variant="outline" className="flex-1 bg-transparent">
                      استفسر
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <p className="text-lg text-gray-600">لا توجد منتجات تطابق معايير البحث</p>
            </div>
          )}
        </div>
      </section>

      {/* Cart Summary */}
      {getCartItemsCount() > 0 && (
        <section className="py-8 px-4 bg-orange-50">
          <div className="container mx-auto max-w-2xl">
            <Card>
              <CardHeader>
                <CardTitle className="text-center">ملخص السلة</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 mb-4">
                  {Object.entries(cart).map(([productId, quantity]) => {
                    const product = products.find((p) => p.id === Number.parseInt(productId))
                    if (!product) return null
                    return (
                      <div key={productId} className="flex justify-between items-center">
                        <span>
                          {product.name} × {quantity}
                        </span>
                        <span>{product.price * quantity} د.ل</span>
                      </div>
                    )
                  })}
                </div>
                <div className="border-t pt-4">
                  <div className="flex justify-between items-center text-lg font-bold">
                    <span>المجموع:</span>
                    <span>{getCartTotal()} د.ل</span>
                  </div>
                </div>
                <div className="flex gap-2 mt-4">
                  <Button className="flex-1 bg-blue-800 hover:bg-blue-900">إتمام الشراء</Button>
                  <Button variant="outline" className="flex-1 bg-transparent">
                    تواصل عبر واتساب
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 px-4">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 space-x-reverse mb-4">
            <Image src="/logos/wast-home-logo.jpeg" alt="متجر وسط هوم" width={32} height={32} className="rounded-lg" />
            <span className="text-xl font-bold">متجر وسط هوم</span>
          </div>
          <p className="text-gray-400 mb-4">جزء من مجموعة وسط للخدمات التسويقية</p>
          <div className="flex justify-center space-x-2 space-x-reverse flex-wrap gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="text-white border-white hover:bg-white hover:text-gray-900 bg-transparent"
              onClick={() => window.open("https://wa.me/218912345681", "_blank")}
            >
              <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.1\
