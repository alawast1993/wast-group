"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Smartphone, Laptop, Headphones, Camera, ShoppingCart, Star, Search, Play, Eye } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { useState } from "react"

export default function ElectronicsPage() {
  const [cart, setCart] = useState<{ [key: number]: number }>({})
  const [searchTerm, setSearchTerm] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("all")

  const products = [
    {
      id: 1,
      name: "آيفون 15 برو ماكس",
      category: "هواتف ذكية",
      price: 4500,
      originalPrice: 4800,
      rating: 4.9,
      reviews: 128,
      image: "/placeholder.svg?height=200&width=200",
      description: "أحدث هاتف من آبل بكاميرا احترافية وأداء فائق",
      features: ["كاميرا 48 ميجابكسل", "شاشة 6.7 بوصة", "معالج A17 Pro", "ذاكرة 256 جيجا"],
      inStock: true,
      isNew: true,
      hasVideo: true,
    },
    {
      id: 2,
      name: "لابتوب ديل XPS 13",
      category: "أجهزة كمبيوتر",
      price: 3200,
      originalPrice: 3500,
      rating: 4.7,
      reviews: 89,
      image: "/placeholder.svg?height=200&width=200",
      description: "لابتوب خفيف وقوي مثالي للعمل والدراسة",
      features: ["معالج Intel i7", "ذاكرة 16 جيجا", "SSD 512 جيجا", "شاشة 4K"],
      inStock: true,
      isNew: false,
      hasVideo: true,
    },
    {
      id: 3,
      name: "سماعات سوني WH-1000XM5",
      category: "سماعات",
      price: 850,
      originalPrice: 950,
      rating: 4.8,
      reviews: 156,
      image: "/placeholder.svg?height=200&width=200",
      description: "سماعات لاسلكية بتقنية إلغاء الضوضاء المتقدمة",
      features: ["إلغاء ضوضاء نشط", "بطارية 30 ساعة", "صوت عالي الدقة", "مقاومة للماء"],
      inStock: true,
      isNew: true,
      hasVideo: false,
    },
    {
      id: 4,
      name: "كاميرا كانون EOS R6",
      category: "كاميرات",
      price: 6500,
      originalPrice: 7000,
      rating: 4.9,
      reviews: 67,
      image: "/placeholder.svg?height=200&width=200",
      description: "كاميرا احترافية مرآة بدون مرآة للمصورين المحترفين",
      features: ["حساس 20 ميجابكسل", "تصوير 4K", "تثبيت صورة", "شاشة لمس"],
      inStock: false,
      isNew: false,
      hasVideo: true,
    },
    {
      id: 5,
      name: "ساعة آبل الذكية Series 9",
      category: "إكسسوارات",
      price: 1200,
      originalPrice: 1350,
      rating: 4.6,
      reviews: 203,
      image: "/placeholder.svg?height=200&width=200",
      description: "ساعة ذكية متقدمة لتتبع الصحة واللياقة",
      features: ["مراقب نبضات", "GPS مدمج", "مقاومة للماء", "شاشة Retina"],
      inStock: true,
      isNew: true,
      hasVideo: false,
    },
    {
      id: 6,
      name: "تابلت سامسونج Galaxy Tab S9",
      category: "تابلت",
      price: 2800,
      originalPrice: 3100,
      rating: 4.5,
      reviews: 94,
      image: "/placeholder.svg?height=200&width=200",
      description: "تابلت قوي للعمل والترفيه مع قلم S Pen",
      features: ["شاشة 11 بوصة", "قلم S Pen", "ذاكرة 128 جيجا", "5G"],
      inStock: true,
      isNew: false,
      hasVideo: true,
    },
  ]

  const categories = [
    { id: "phones", name: "هواتف ذكية", icon: <Smartphone className="h-5 w-5" /> },
    { id: "computers", name: "أجهزة كمبيوتر", icon: <Laptop className="h-5 w-5" /> },
    { id: "audio", name: "سماعات", icon: <Headphones className="h-5 w-5" /> },
    { id: "cameras", name: "كاميرات", icon: <Camera className="h-5 w-5" /> },
  ]

  const addToCart = (productId: number) => {
    setCart((prev) => ({
      ...prev,
      [productId]: (prev[productId] || 0) + 1,
    }))
  }

  const getCartTotal = () => {
    return Object.entries(cart).reduce((total, [productId, quantity]) => {
      const product = products.find((p) => p.id === Number.parseInt(productId))
      return total + (product ? product.price * quantity : 0)
    }, 0)
  }

  const getCartItemsCount = () => {
    return Object.values(cart).reduce((total, quantity) => total + quantity, 0)
  }

  const filteredProducts = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = categoryFilter === "all" || product.category === categoryFilter

    return matchesSearch && matchesCategory
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-4 space-x-reverse">
              <Image
                src="/logos/wastcm-electronics-logo.png"
                alt="متجر وسطكم للإلكترونيات"
                width={40}
                height={40}
                className="rounded-lg"
              />
              <div>
                <h1 className="text-xl font-bold text-gray-900">متجر وسطكم</h1>
                <p className="text-sm text-gray-600">للإلكترونيات</p>
              </div>
            </Link>
            <div className="flex items-center space-x-4 space-x-reverse">
              <Button variant="outline" className="relative bg-transparent">
                <ShoppingCart className="h-5 w-5 ml-2" />
                السلة
                {getCartItemsCount() > 0 && (
                  <Badge className="absolute -top-2 -right-2 bg-red-500 text-white text-xs">
                    {getCartItemsCount()}
                  </Badge>
                )}
              </Button>
              <nav className="hidden md:flex items-center space-x-6 space-x-reverse">
                <Link href="/" className="text-gray-700 hover:text-purple-600 font-medium">
                  الرئيسية
                </Link>
                <Link href="#products" className="text-gray-700 hover:text-purple-600 font-medium">
                  المنتجات
                </Link>
                <Link href="#showcase" className="text-gray-700 hover:text-purple-600 font-medium">
                  العروض التوضيحية
                </Link>
              </nav>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-blue-800 to-cyan-500 text-white">
        <div className="container mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">متجر وسطكم للإلكترونيات</h1>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            أحدث الأجهزة الإلكترونية والتقنية بأفضل الأسعار مع ضمان الجودة والأصالة
          </p>
        </div>
      </section>

      {/* Product Showcase & Demos */}
      <section id="showcase" className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">عروض توضيحية للمنتجات</h2>
            <p className="text-lg text-gray-600">شاهد المنتجات عن قرب واكتشف مميزاتها</p>
          </div>

          {/* Featured Video Demo */}
          <div className="mb-12">
            <Card className="overflow-hidden">
              <CardContent className="p-0">
                <div className="relative">
                  <Image
                    src="/placeholder.svg?height=400&width=800"
                    alt="عرض توضيحي"
                    width={800}
                    height={400}
                    className="w-full h-96 object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                    <Button 
                      size="lg" 
                      className="bg-purple-600 hover:bg-purple-700 text-white"
                      onClick={() => window.open("https://www.youtube.com/watch?v=dQw4w9WgXcQ", "_blank")}
                    >
                      <Play className="w-8 h-8 ml-2" />
                      شاهد العرض التوضيحي الشامل
                    </Button>
                  </div>
                  <div className="absolute bottom-4 left-4 text-white">
                    <h3 className="text-xl font-bold">جولة في متجر وسطكم</h3>
                    <p>اكتشف أحدث المنتجات والعروض</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Product Demo Grid */}
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            {[
              {
                title: "مراجعة شاملة للآيفون 15 برو",
                category: "هواتف ذكية",
                image: "/placeholder.svg?height=200&width=300",
                duration: "8 دقائق",
                views: "15K"
              },
              {
                title: "اختبار أداء لابتوب ديل XPS",
                category: "أجهزة كمبيوتر",
                image: "/placeholder.svg?height=200&width=300",
                duration: "12 دقيقة",
                views: "8.5K"
              },
              {
                title: "تجربة سماعات سوني الجديدة",
                category: "سماعات",
                image: "/placeholder.svg?height=200&width=300",
                duration: "6 دقائق",
                views: "12K"
              },
              {
                title: "مقارنة كاميرات احترافية",
                category: "كاميرات",
                image: "/placeholder.svg?height=200&width=300",
                duration: "15 دقيقة",
                views: "20K"
              },
              {
                title: "مميزات ساعة آبل الجديدة",
                category: "إكسسوارات",
                image: "/placeholder.svg?height=200&width=300",
                duration: "7 دقائق",
                views: "9K"
              },
              {
                title: "تابلت سامسونج للمحترفين",
                category: "تابلت",
                image: "/placeholder.svg?height=200&width=300",
                duration: "10 دقائق",
                views: "6.8K"
              }
            ].map((demo, index) => (
              <Card key={index} className="group hover:shadow-lg transition-shadow overflow-hidden cursor-pointer">
                <div className="relative">
                  <Image
                    src={demo.image || "/placeholder.svg"}
                    alt={demo.title}
                    width={300}
                    height={200}
                    className="w-full h-40 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Button size="sm" className="bg-white text-gray-900 hover:bg-gray-100">
                      <Play className="w-4 h-4 ml-1" />
                      مشاهدة
                    </Button>
                  </div>
                  <div className="absolute top-2 right-2">
                    <Badge className="bg-purple-600 text-white">{demo.category}</Badge>
                  </div>
                  <div className="absolute bottom-2 left-2 flex gap-2">
                    <Badge variant="secondary" className="bg-black bg-opacity-50 text-white">
                      {demo.duration}
                    </Badge>
                    <Badge variant="secondary" className="bg-black bg-opacity-50 text-white">
                      <Eye className="w-3 h-3 ml-1" />
                      {demo.views}
                    </Badge>
                  </div>
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold text-gray-900">{demo.title}</h3>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Live Demo Schedule */}
          <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-center text-gray-900 mb-6">العروض التوضيحية المباشرة</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-white rounded-lg p-6">
                  <h4 className="font-bold text-gray-900 mb-3">عرض مباشر اليوم</h4>
                  <p className="text-gray-600 mb-4">مراجعة شاملة لأحدث الهواتف الذكية</p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">الساعة 8:00 مساءً</span>
                    <Button size="sm" className="bg-red-600 hover:bg-red-700">
                      <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 24 24">
                        <circle cx="12" cy="12" r="3"/>
                      </svg>
                      مباشر
                    </Button>
                  </div>
                </div>
                <div className="bg-white rounded-lg p-6">
                  <h4 className="font-bold text-gray-900 mb-3">العرض القادم</h4>
                  <p className="text-gray-600 mb-4">اختبار أداء أجهزة الكمبيوتر المحمولة</p>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">غداً - 7:00 مساءً</span>
                    <Button size="sm" variant="outline">
                      تذكيرني
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Categories */}
      <section className="py-8 px-4 bg-gray-50">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-4">
            {categories.map((category) => (
              <Card key={category.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-4 text-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3 text-purple-600">
                    {category.icon}
                  </div>
                  <h3 className="font-semibold text-gray-900">{category.name}</h3>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Search and Filters */}
      <section className="py-8 px-4 bg-white">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-2 gap-4 max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="ابحث عن المنتجات..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10"
              />
            </div>
            <div>
              <Select onValueChange={setCategoryFilter} value={categoryFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="جميع الفئات" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">جميع الفئات</SelectItem>
                  <SelectItem value="هواتف ذكية">هواتف ذكية</SelectItem>
                  <SelectItem value="أجهزة كمبيوتر">أجهزة كمبيوتر</SelectItem>
                  <SelectItem value="سماعات">سماعات</SelectItem>
                  <SelectItem value="كاميرات">كاميرات</SelectItem>
                  <SelectItem value="إكسسوارات">إكسسوارات</SelectItem>
                  <SelectItem value="تابلت">تابلت</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section id="products" className="py-16 px-4 bg-gray-50">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">منتجاتنا</h2>
            <p className="text-lg text-gray-600">اختر من مجموعة متنوعة من الأجهزة الإلكترونية عالية الجودة</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map((product) => (
              <Card key={product.id} className="hover:shadow-xl transition-shadow duration-300 overflow-hidden">
                <div className="relative">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    width={200}
                    height={200}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-4 right-4 flex flex-col gap-2">
                    {product.isNew && <Badge className="bg-green-600">جديد</Badge>}
                    {product.originalPrice > product.price && <Badge className="bg-red-600">خصم</Badge>}
                    {!product.inStock && <Badge variant="secondary">نفد المخزون</Badge>}
                    {product.hasVideo && (
                      <Badge className="bg-purple-600">
                        <Play className="w-3 h-3 ml-1" />
                        فيديو
                      </Badge>
                    )}
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-lg font-bold">{product.name}</CardTitle>
                  <CardDescription className="text-gray-600">{product.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center mb-3">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${
                            i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-600 mr-2">({product.reviews} تقييم)</span>
                  </div>

                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <div className="text-2xl font-bold text-purple-600">{product.price} د.ل</div>
                      {product.originalPrice > product.price && (
                        <div className="text-sm text-gray-500 line-through">{product.originalPrice} د.ل</div>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1 mb-4">
                    {product.features.slice(0, 2).map((feature, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex gap-2">
                    <Button
                      className="flex-1 bg-blue-800 hover:bg-blue-900"
                      onClick={() => addToCart(product.id)}
                      disabled={!product.inStock}
                    >
                      <ShoppingCart className="h-4 w-4 ml-1" />
                      {product.inStock ? "أضف للسلة" : "نفد المخزون"}
                    </Button>
                    {product.hasVideo && (
                      <Button variant="outline" size="sm">
                        <Play className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="text-center py-12">
              <p className="text-lg text-gray-600">لا توجد منتجات تطابق معايير البحث</p>
            </div>
          )}
        </div>
      </section>

      {/* Cart Summary */}
      {getCartItemsCount() > 0 && (
        <section className="py-8 px-4 bg-purple-50">
          <div className="container mx-auto max-w-2xl">
            <Card>
              <CardHeader>
                <CardTitle className="text-center">ملخص السلة</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 mb-4">
                  {Object.entries(cart).map(([productId, quantity]) => {
                    const product = products.find((p) => p.id === Number.parseInt(productId))
                    if (!product) return null
                    return (
                      <div key={productId} className="flex justify-between items-center">
                        <span>
                          {product.name} × {quantity}
                        </span>
                        <span>{product.price * quantity} د.ل</span>
                      </div>
                    )
                  })}
                </div>
                <div className="border-t pt-4">
                  <div className="flex justify-between items-center text-lg font-bold">
                    <span>المجموع:</span>
                    <span>{getCartTotal()} د.ل</span>
                  </div>
                </div>
                <div className="flex gap-2 mt-4">
                  <Button className="flex-1 bg-blue-800 hover:bg-blue-900">إتمام الشراء</Button>
                  <Button variant="outline" className="flex-1 bg-transparent">
                    تواصل عبر واتساب
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 px-4">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 space-x-reverse mb-4">
            <Image src="/logos/wastcm-electronics-logo.png" alt="متجر وسطكم" width={32} height={32} className="rounded-lg" />
            <span className="text-xl font-bold">متجر وسطكم</span>
          </div>
          <p className="text-gray-400 mb-4">جزء من مجموعة وسط للخدمات التسويقية</p>
          <div className="flex justify-center space-x-2 space-x-reverse flex-wrap gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="text-white border-white hover:bg-white hover:text-gray-900 bg-transparent"
              onClick={() => window.open("https://wa.me/218919835505", "_blank")}
            >
              <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488" />
              </svg>
              واتساب
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="text-white border-white hover:bg-white hover:text-gray-900 bg-transparent"
              onClick={() => window.open("https://facebook.com/wasatkm.electronics", "_blank")}
            >
              <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
              </svg>
              فيسبوك
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="text-white border-white hover:bg-white hover:text-gray-900 bg-transparent"
              onClick={() => window.open("https://instagram.com/wasatkm.electronics", "_blank")}
            >
              <svg className="w-4 h-4 ml-1" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919\
