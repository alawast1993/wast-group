"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Shield, Lock, Eye, Database, UserCheck } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-4 space-x-reverse">
              <Image src="/logos/wasat-group-main.png" alt="مجموعة وسط" width={40} height={40} className="rounded-lg" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">مجموعة وسط</h1>
                <p className="text-sm text-gray-600">للخدمات التسويقية</p>
              </div>
            </Link>
            <nav className="hidden md:flex items-center space-x-6 space-x-reverse">
              <Link href="/" className="text-gray-700 hover:text-blue-600 font-medium">
                الرئيسية
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-blue-600 font-medium">
                من نحن
              </Link>
              <Link href="/contact" className="text-gray-700 hover:text-blue-600 font-medium">
                تواصل معنا
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-green-600 to-cyan-500 text-white">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center mb-6">
            <Shield className="h-16 w-16 text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">سياسة الخصوصية</h1>
          <p className="text-xl mb-8 max-w-3xl mx-auto">نحن نقدر خصوصيتك، وملتزمون بحماية بياناتك الشخصية</p>
        </div>
      </section>

      {/* Content */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          {/* Introduction */}
          <Card className="mb-8">
            <CardHeader>
              <div className="flex items-center space-x-3 space-x-reverse">
                <Lock className="h-6 w-6 text-green-600" />
                <CardTitle className="text-2xl">التزامنا بخصوصيتك</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 leading-relaxed">
                في مجموعة وسط للخدمات التسويقية، نحن ملتزمون بحماية خصوصيتك وأمان بياناتك الشخصية. هذه السياسة توضح
                كيفية جمع واستخدام وحماية المعلومات التي تقدمها لنا.
              </p>
            </CardContent>
          </Card>

          {/* Privacy Sections */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-3 space-x-reverse">
                  <Database className="h-5 w-5 text-green-600" />
                  <CardTitle className="text-xl text-green-700">1. المعلومات التي نجمعها</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 mb-4">قد نقوم بجمع بعض المعلومات عند استخدامك للموقع، مثل:</p>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-green-600 rounded-full ml-3"></span>
                    الاسم
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-green-600 rounded-full ml-3"></span>
                    البريد الإلكتروني
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-green-600 rounded-full ml-3"></span>
                    رقم الهاتف
                  </li>
                  <li className="flex items-center">
                    <span className="w-2 h-2 bg-green-600 rounded-full ml-3"></span>
                    تفاصيل الطلبات أو الاستفسارات
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center space-x-3 space-x-reverse">
                  <Eye className="h-5 w-5 text-green-600" />
                  <CardTitle className="text-xl text-green-700">2. كيف نستخدم المعلومات</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-green-600 rounded-full mt-2 ml-3 flex-shrink-0"></span>
                    للرد على استفساراتك أو تنفيذ الطلبات
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-green-600 rounded-full mt-2 ml-3 flex-shrink-0"></span>
                    لتحسين خدماتنا وتجربة المستخدم
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-green-600 rounded-full mt-2 ml-3 flex-shrink-0"></span>
                    لإرسال تحديثات وعروض (بموافقتك)
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center space-x-3 space-x-reverse">
                  <Shield className="h-5 w-5 text-green-600" />
                  <CardTitle className="text-xl text-green-700">3. حماية البيانات</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  نستخدم إجراءات أمان مناسبة لحماية بياناتك من الوصول غير المصرح به أو الاستخدام غير المشروع. جميع
                  البيانات محمية بتقنيات التشفير المتقدمة.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center space-x-3 space-x-reverse">
                  <UserCheck className="h-5 w-5 text-green-600" />
                  <CardTitle className="text-xl text-green-700">4. مشاركة المعلومات</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-green-600 rounded-full mt-2 ml-3 flex-shrink-0"></span>
                    لا نشارك بياناتك مع أي طرف ثالث دون موافقتك، باستثناء الحالات القانونية.
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-green-600 rounded-full mt-2 ml-3 flex-shrink-0"></span>
                    قد نستخدم خدمات طرف ثالث (مثل أدوات تحليل الزوّار) دون أن تضر بخصوصيتك.
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-green-700">5. ملفات تعريف الارتباط (Cookies)</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  يستخدم الموقع ملفات تعريف الارتباط لتحسين تجربة المستخدم وتحليل استخدام الموقع. يمكنك تعطيلها من
                  إعدادات المتصفح إذا كنت تفضل ذلك.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-green-700">6. حقوقك</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed mb-4">لديك الحق في:</p>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-green-600 rounded-full mt-2 ml-3 flex-shrink-0"></span>
                    طلب معرفة البيانات التي نحتفظ بها عنك
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-green-600 rounded-full mt-2 ml-3 flex-shrink-0"></span>
                    طلب تعديل أو تصحيح بياناتك
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-green-600 rounded-full mt-2 ml-3 flex-shrink-0"></span>
                    طلب حذف بياناتك من أنظمتنا
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-green-700">7. التعديلات</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  نحتفظ بالحق في تعديل سياسة الخصوصية في أي وقت. سيتم نشر التعديلات على هذه الصفحة مع تاريخ آخر تحديث.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Contact Section */}
          <Card className="mt-8 bg-gradient-to-r from-green-50 to-cyan-50 border-green-200">
            <CardContent className="p-6 text-center">
              <h3 className="text-xl font-bold text-gray-900 mb-4">هل لديك أسئلة حول سياسة الخصوصية؟</h3>
              <p className="text-gray-600 mb-6">إذا كان لديك أي استفسار حول كيفية التعامل مع بياناتك، تواصل معنا</p>
              <Link href="/contact">
                <Button className="bg-green-600 hover:bg-green-700">
                  تواصل معنا
                  <ArrowLeft className="mr-2 h-4 w-4" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 space-x-reverse mb-4">
                <Image
                  src="/logos/wasat-group-main.png"
                  alt="مجموعة وسط"
                  width={32}
                  height={32}
                  className="rounded-lg"
                />
                <span className="text-xl font-bold">مجموعة وسط</span>
              </div>
              <p className="text-gray-400 text-sm">مجموعة متكاملة من الخدمات التسويقية والتجارية المتطورة</p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">فروعنا</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link href="/marketing" className="hover:text-white">
                    وسط آيديا
                  </Link>
                </li>
                <li>
                  <Link href="/real-estate" className="hover:text-white">
                    العقارات
                  </Link>
                </li>
                <li>
                  <Link href="/electronics" className="hover:text-white">
                    الإلكترونيات
                  </Link>
                </li>
                <li>
                  <Link href="/home-store" className="hover:text-white">
                    المستلزمات المنزلية
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">روابط سريعة</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link href="/about" className="hover:text-white">
                    من نحن
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white">
                    تواصل معنا
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-white text-green-400">
                    سياسة الخصوصية
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-white">
                    الشروط والأحكام
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">تابعنا</h3>
              <div className="flex space-x-4 space-x-reverse">
                <a
                  href="https://www.facebook.com/wast.group"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center hover:bg-blue-700"
                >
                  <span className="text-xs">ف</span>
                </a>
                <a
                  href="https://wa.me/218919835505"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center hover:bg-green-700"
                >
                  <span className="text-xs">و</span>
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2024 مجموعة وسط للخدمات التسويقية. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
