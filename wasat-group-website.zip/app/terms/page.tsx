"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, FileText, AlertCircle } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100" dir="rtl">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-4 space-x-reverse">
              <Image src="/logos/wasat-group-main.png" alt="مجموعة وسط" width={40} height={40} className="rounded-lg" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">مجموعة وسط</h1>
                <p className="text-sm text-gray-600">للخدمات التسويقية</p>
              </div>
            </Link>
            <nav className="hidden md:flex items-center space-x-6 space-x-reverse">
              <Link href="/" className="text-gray-700 hover:text-blue-600 font-medium">
                الرئيسية
              </Link>
              <Link href="/about" className="text-gray-700 hover:text-blue-600 font-medium">
                من نحن
              </Link>
              <Link href="/contact" className="text-gray-700 hover:text-blue-600 font-medium">
                تواصل معنا
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-blue-800 to-cyan-500 text-white">
        <div className="container mx-auto text-center">
          <div className="flex items-center justify-center mb-6">
            <FileText className="h-16 w-16 text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">الشروط والأحكام</h1>
          <p className="text-xl mb-8 max-w-3xl mx-auto">شروط وأحكام استخدام موقع مجموعة وسط للخدمات التسويقية</p>
        </div>
      </section>

      {/* Content */}
      <section className="py-16 px-4">
        <div className="container mx-auto max-w-4xl">
          {/* Introduction */}
          <Card className="mb-8">
            <CardHeader>
              <div className="flex items-center space-x-3 space-x-reverse">
                <AlertCircle className="h-6 w-6 text-blue-600" />
                <CardTitle className="text-2xl">مقدمة</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 leading-relaxed">
                مرحبًا بكم في موقع مجموعة وسط للخدمات التسويقية. باستخدامك لهذا الموقع، فإنك توافق على الالتزام بالشروط
                والأحكام التالية. إذا كنت لا توافق على أي جزء منها، يُرجى عدم استخدام الموقع.
              </p>
            </CardContent>
          </Card>

          {/* Terms Sections */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-blue-800">1. القبول بالشروط</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  باستخدامك للموقع، فإنك توافق على الالتزام بهذه الشروط والسياسات الأخرى المعروضة، والتي قد يتم تعديلها
                  من وقت لآخر.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-blue-800">2. استخدام الموقع</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 ml-3 flex-shrink-0"></span>
                    يُستخدم الموقع لعرض وطلب خدماتنا ومنتجاتنا فقط.
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 ml-3 flex-shrink-0"></span>
                    يُمنع استخدام الموقع لأي غرض غير قانوني أو ينتهك الحقوق أو الملكية الفكرية للمجموعة أو أطراف أخرى.
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-blue-800">3. طلب الخدمات والمنتجات</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 ml-3 flex-shrink-0"></span>
                    عند إرسال نموذج طلب، يجب تقديم معلومات دقيقة وصحيحة.
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 ml-3 flex-shrink-0"></span>
                    تحتفظ إدارة الموقع بحقها في قبول أو رفض أي طلب دون إبداء الأسباب.
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-blue-800">4. المحتوى</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  جميع النصوص، التصاميم، الصور، والشعارات على الموقع هي ملك حصري لـ "مجموعة وسط" ولا يجوز استخدامها دون
                  إذن خطي.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-blue-800">5. حدود المسؤولية</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 ml-3 flex-shrink-0"></span>
                    لا نتحمل أي مسؤولية عن أي أضرار ناتجة عن استخدام الموقع أو عدم القدرة على استخدامه.
                  </li>
                  <li className="flex items-start">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mt-2 ml-3 flex-shrink-0"></span>
                    يتم تقديم المعلومات والخدمات "كما هي" بدون أي ضمانات.
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-blue-800">6. الروابط الخارجية</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  قد يحتوي الموقع على روابط إلى مواقع خارجية. لسنا مسؤولين عن محتوى أو ممارسات تلك المواقع.
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-xl text-blue-800">7. التعديلات</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  نحتفظ بالحق في تعديل هذه الشروط في أي وقت. سيتم نشر التعديلات على هذه الصفحة، ويُعتبر استمرارك في
                  استخدام الموقع موافقة عليها.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Contact Section */}
          <Card className="mt-8 bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200">
            <CardContent className="p-6 text-center">
              <h3 className="text-xl font-bold text-gray-900 mb-4">هل لديك أسئلة حول الشروط والأحكام؟</h3>
              <p className="text-gray-600 mb-6">إذا كان لديك أي استفسار حول هذه الشروط، لا تتردد في التواصل معنا</p>
              <Link href="/contact">
                <Button className="bg-blue-600 hover:bg-blue-700">
                  تواصل معنا
                  <ArrowLeft className="mr-2 h-4 w-4" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 space-x-reverse mb-4">
                <Image
                  src="/logos/wasat-group-main.png"
                  alt="مجموعة وسط"
                  width={32}
                  height={32}
                  className="rounded-lg"
                />
                <span className="text-xl font-bold">مجموعة وسط</span>
              </div>
              <p className="text-gray-400 text-sm">مجموعة متكاملة من الخدمات التسويقية والتجارية المتطورة</p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">فروعنا</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link href="/marketing" className="hover:text-white">
                    وسط آيديا
                  </Link>
                </li>
                <li>
                  <Link href="/real-estate" className="hover:text-white">
                    العقارات
                  </Link>
                </li>
                <li>
                  <Link href="/electronics" className="hover:text-white">
                    الإلكترونيات
                  </Link>
                </li>
                <li>
                  <Link href="/home-store" className="hover:text-white">
                    المستلزمات المنزلية
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">روابط سريعة</h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link href="/about" className="hover:text-white">
                    من نحن
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-white">
                    تواصل معنا
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="hover:text-white">
                    سياسة الخصوصية
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="hover:text-white text-blue-400">
                    الشروط والأحكام
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">تابعنا</h3>
              <div className="flex space-x-4 space-x-reverse">
                <a
                  href="https://www.facebook.com/wast.group"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center hover:bg-blue-700"
                >
                  <span className="text-xs">ف</span>
                </a>
                <a
                  href="https://wa.me/218919835505"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center hover:bg-green-700"
                >
                  <span className="text-xs">و</span>
                </a>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2024 مجموعة وسط للخدمات التسويقية. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
